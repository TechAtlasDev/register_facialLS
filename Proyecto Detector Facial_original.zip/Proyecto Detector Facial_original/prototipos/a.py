""" MANERA DE USAR DE MANERA ADECUADA UNA FUNCION DE DATAEXC """
import dataexc

data_list = dataexc.busqueda(["nombres", "cargo"], "data_users", "dni", 77809977)
